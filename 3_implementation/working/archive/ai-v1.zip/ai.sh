. env.sh

eval $JAVA_CMD:./ai.jar net.ea.Starter